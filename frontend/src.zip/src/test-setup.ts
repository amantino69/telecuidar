// Vitest setup file
// This file is automatically included by Vitest before running tests
