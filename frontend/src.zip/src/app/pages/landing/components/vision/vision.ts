import { Component } from '@angular/core';

@Component({
  selector: 'app-vision',
  standalone: true,
  templateUrl: './vision.html',
  styleUrl: './vision.scss'
})
export class VisionComponent {}
