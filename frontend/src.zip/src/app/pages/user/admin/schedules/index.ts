export { SchedulesComponent } from '@pages/user/admin/schedules/schedules';
