export const environment = {
  production: true,
  apiUrl: '/api', // Production API URL - configure based on deployment
  apiUrlHttp: '/api',
};
